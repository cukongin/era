<?php

use App\Models\Siswa;
use App\Models\NilaiSiswa;
use App\Models\Kelas;
use Illuminate\Support\Facades\DB;

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

echo "=== Global Grade Level Distribution ===\n";

try {
    $levels = NilaiSiswa::join('kelas', 'nilai_siswa.id_kelas', '=', 'kelas.id')
        ->select('kelas.tingkat_kelas', DB::raw('count(*) as count'))
        ->groupBy('kelas.tingkat_kelas')
        ->orderBy('kelas.tingkat_kelas')
        ->get();

    if ($levels->isEmpty()) {
        echo "No grades found in the system linked to classes.\n";
    }

    foreach($levels as $l) {
        echo "Level " . $l->tingkat_kelas . ": " . $l->count . " records\n";
    }

    echo "\n=== Class 6 Population ===\n";
    $class6 = Kelas::where('nama_kelas', 'like', '%6%')->get();
    
    if ($class6->isEmpty()) {
        echo "No Class 6 found.\n";
    }

    foreach($class6 as $c) {
        echo $c->nama_kelas . " (ID: " . $c->id . "): " . $c->anggota_kelas()->count() . " students\n";
    }

     echo "\n=== Class 9 Population ===\n";
    $class9 = Kelas::where('nama_kelas', 'like', '%9%')->get();
    
    if ($class9->isEmpty()) {
        echo "No Class 9 found.\n";
    }

    foreach($class9 as $c) {
        echo $c->nama_kelas . " (ID: " . $c->id . "): " . $c->anggota_kelas()->count() . " students\n";
    }


} catch (\Exception $e) {
    echo "Error: " . $e->getMessage();
}
