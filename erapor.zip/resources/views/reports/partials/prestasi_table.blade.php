<table class="w-full text-xs text-left border-collapse rapor-table">
    <thead class="bg-gray-100 text-center font-bold">
        <tr>
            <th class="w-8" rowspan="2">No</th>
            <th rowspan="2">Jenis Prestasi</th>
            <th rowspan="2">Keterangan</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="text-center">-</td>
            <td>-</td>
            <td>-</td>
        </tr>
    </tbody>
</table>
