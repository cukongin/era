<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IdentitasSekolah extends Model
{
    protected $table = 'identitas_sekolah';
    protected $guarded = ['id'];
}
