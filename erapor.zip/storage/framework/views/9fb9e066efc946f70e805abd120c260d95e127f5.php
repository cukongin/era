<!DOCTYPE html>
<html>
<head>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 0.5pt solid #000; padding: 4px; } /* Thinnest possible */
        .text-center { text-align: center; }
        .bg-header { background-color: #f0f0f0; font-weight: bold; }
        .text-red { color: red; }
    </style>
</head>
<body>
    <h2>LEGER NILAI KELAS <?php echo e($kelas->nama_kelas); ?></h2>
    <p>Periode: <?php echo e($periode->nama_periode); ?> | Total Siswa: <?php echo e($students->count()); ?></p>
    
    <table>
        <thead>
            <tr class="bg-header">
                <th rowspan="2" style="background-color:#eee; border:0.5pt solid #000;">No</th>
                <th rowspan="2" style="background-color:#eee; border:0.5pt solid #000;">NIS</th>
                <th rowspan="2" style="background-color:#eee; border:0.5pt solid #000;">Nama Siswa</th>
                <th rowspan="2" style="background-color:#eee; border:0.5pt solid #000;">L/P</th>
                <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th class="text-center" style="background-color:#eee; border:0.5pt solid #000;"><?php echo e($mapel->nama_mapel); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th rowspan="2" style="background-color:#eee; border:0.5pt solid #000;">Total Nilai</th>
                <th rowspan="2" style="background-color:#eee; border:0.5pt solid #000;">Rata-rata</th>
                <th rowspan="2" style="background-color:#eee; border:0.5pt solid #000;">Ranking</th>
            </tr>
            <tr class="bg-header">
                <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th class="text-center" style="font-size:10px; background-color:#f8f9fa; border:0.5pt solid #000;">KKM: <?php echo e($kkm[$mapel->id] ?? 70); ?></th> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $stats = $studentStats[$ak->id_siswa] ?? ['total'=>0, 'avg'=>0, 'rank'=>'-'];
                $sGrades = $grades[$ak->id_siswa] ?? collect([]);
            ?>
            <tr>
                <td class="text-center" style="border:0.5pt solid #000;"><?php echo e($index + 1); ?></td>
                <td class="text-center" style="mso-number-format:'\@'; border:0.5pt solid #000;"><?php echo e($ak->siswa->nis_lokal); ?></td>
                <td style="border:0.5pt solid #000;"><?php echo e($ak->siswa->nama_lengkap); ?></td>
                <td class="text-center" style="border:0.5pt solid #000;"><?php echo e($ak->siswa->jenis_kelamin); ?></td>
                
                <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $grade = $sGrades->where('id_mapel', $mapel->id)->first();
                        
                        $score = 0;
                        if ($grade) {
                            $score = (!empty($showOriginal)) ? ($grade->nilai_akhir_asli ?? $grade->nilai_akhir) : $grade->nilai_akhir;
                        }

                        $kkmVal = $kkm[$mapel->id] ?? 70;
                        $style = 'border:0.5pt solid #000;'; // Removed fixed decimal format
                        if ($grade && $score < $kkmVal) $style .= ' color: red;';
                        
                        // Highlight if Katrol (only in Original Mode)
                        if (!empty($showOriginal) && $grade) {
                            $final = $grade->nilai_akhir;
                            $original = $grade->nilai_akhir_asli ?? $final;
                            if ($final != $original) {
                                $style .= ' background-color: #fff9c4;'; // Light Yellow
                            }
                        }
                    ?>
                    <td class="text-center" style="<?php echo e($style); ?>">
                        <?php echo e($grade ? round($score) : '-'); ?>

                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <td class="text-center" style="border:0.5pt solid #000; background-color: #e3f2fd; font-weight: bold; mso-number-format:'0\.00';"><?php echo e(number_format($stats['total'])); ?></td>
                <td class="text-center" style="border:0.5pt solid #000; background-color: #bbdefb; font-weight: bold; mso-number-format:'0\.00';"><?php echo e(number_format($stats['avg'], 2)); ?></td>
                <td class="text-center font-bold" style="border:0.5pt solid #000; background-color: #fff9c4; color: black;"><?php echo e($stats['rank']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\erapor\resources\views/wali-kelas/leger-export.blade.php ENDPATH**/ ?>