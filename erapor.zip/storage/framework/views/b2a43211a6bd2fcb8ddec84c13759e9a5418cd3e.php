<!DOCTYPE html>
<html>
<head>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 0.5pt solid #000; padding: 4px; } /* Thinnest possible in HTML-to-Excel */
        .text-center { text-align: center; }
        .bg-header { background-color: #f0f0f0; font-weight: bold; }
        .text-red { color: red; }
    </style>
</head>
<body>
    <h2>LEGER REKAP TAHUNAN KELAS <?php echo e($kelas->nama_kelas); ?></h2>
    <p>Tahun Ajaran: <?php echo e($kelas->tahun_ajaran->nama_tahun); ?> | Total Siswa: <?php echo e($students->count()); ?></p>
    
    <table>
        <thead>
            <tr class="bg-header">
                <th rowspan="2" style="border:0.5pt solid #000;">No</th>
                <th rowspan="2" style="border:0.5pt solid #000;">NIS</th>
                <th rowspan="2" style="border:0.5pt solid #000;">Nama Siswa</th>
                <th rowspan="2" style="border:0.5pt solid #000;">L/P</th>
                
                <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th colspan="<?php echo e($periods->count() + 1); ?>" class="text-center" style="border:0.5pt solid #000;">
                    <?php echo e($mapel->nama_mapel); ?><br>
                    <span style="font-size:10px; font-weight:normal;">KKM: <?php echo e($kkm[$mapel->id] ?? 70); ?></span>
                </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <th rowspan="2" style="border:0.5pt solid #000;">Nilai Total</th>
                <th rowspan="2" style="border:0.5pt solid #000;">Rata-rata Total</th>
                <th rowspan="2" style="border:0.5pt solid #000;">Ranking</th>
            </tr>
            <tr class="bg-header">
                <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th style="border:0.5pt solid #000;"><?php echo e($periode->nama_periode); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th style="background-color: #e0e0e0; border:0.5pt solid #000;">Rata2</th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $myStats = $studentStats[$ak->id_siswa] ?? ['avg'=>0, 'total'=>0, 'rank'=>'-'];
                $sGrades = $grades[$ak->id_siswa] ?? collect([]);
            ?>
            <tr>
                <td class="text-center" style="border:0.5pt solid #000;"><?php echo e($index + 1); ?></td>
                <td class="text-center" style="mso-number-format:'\@'; border:0.5pt solid #000;"><?php echo e($ak->siswa->nis_lokal); ?></td>
                <td style="border:0.5pt solid #000;"><?php echo e($ak->siswa->nama_lengkap); ?></td>
                <td class="text-center" style="border:0.5pt solid #000;"><?php echo e($ak->siswa->jenis_kelamin); ?></td>

                <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $mapelTotal = 0;
                        $mapelCount = 0;
                    ?>
                    <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $g = $sGrades->first(function($item) use ($periode, $mapel) {
                                return $item->id_periode == $periode->id && $item->id_mapel == $mapel->id;
                            });
                            $val = $g ? $g->nilai_akhir : 0;
                            if($g) {
                                $mapelTotal += $val;
                                $mapelCount++;
                            }
                            $style = 'text-center; border:0.5pt solid #000;'; // Removed fixed decimal
                            if ($g && $val < ($kkm[$mapel->id] ?? 70)) $style .= ' color: red;';
                        ?>
                        <td class="text-center" style="<?php echo e($style); ?>">
                            <?php echo e($g ? round($val) : '-'); ?>

                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php
                        $avgMapel = $mapelCount > 0 ? $mapelTotal / $mapelCount : 0;
                    ?>
                    <td class="text-center" style="background-color: #fff8e1; font-weight:bold; border:0.5pt solid #000; mso-number-format:'0\.00';">
                        <?php echo e($mapelCount > 0 ? number_format($avgMapel) : '-'); ?>

                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <td class="text-center font-bold" style="background-color: #e3f2fd; border: 0.5pt solid #000; mso-number-format:'0\.00';"><?php echo e(number_format($myStats['total'])); ?></td>
                <td class="text-center font-bold" style="background-color: #bbdefb; border: 0.5pt solid #000; mso-number-format:'0\.00';"><?php echo e(number_format($myStats['avg'], 2)); ?></td>
                <td class="text-center font-bold" style="background-color: #fff9c4; border: 0.5pt solid #000; color: #000;"><?php echo e($myStats['rank']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\erapor\resources\views/wali-kelas/leger-rekap-export.blade.php ENDPATH**/ ?>