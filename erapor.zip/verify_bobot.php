<?php
require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;
use App\Models\TahunAjaran;

$activeYear = TahunAjaran::where('status', 'aktif')->first();
echo "Active Year: " . $activeYear->nama_tahun . "\n";

$bobotMI = DB::table('bobot_penilaian')
    ->where('id_tahun_ajaran', $activeYear->id)
    ->where('jenjang', 'MI')
    ->first();

$bobotMTS = DB::table('bobot_penilaian')
    ->where('id_tahun_ajaran', $activeYear->id)
    ->where('jenjang', 'MTS')
    ->first();

echo "MI: H={$bobotMI->bobot_harian}% UTS={$bobotMI->bobot_uts_cawu}% UAS={$bobotMI->bobot_uas}%\n";
echo "MTS: H={$bobotMTS->bobot_harian}% UTS={$bobotMTS->bobot_uts_cawu}% UAS={$bobotMTS->bobot_uas}%\n";
