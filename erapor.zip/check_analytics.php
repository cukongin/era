<?php

use App\Models\NilaiSiswa;
use App\Models\Mapel;
use Illuminate\Support\Facades\DB;

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

echo "=== Subject Analysis Check ===\n";

// Use a sample cohort or just global
// Get top 5 subjects with lowest average (Hardest)
$hardest = NilaiSiswa::join('mapel', 'nilai_siswa.id_mapel', '=', 'mapel.id')
    ->select('mapel.nama_mapel', DB::raw('AVG(nilai_siswa.nilai_akhir) as avg_score'))
    ->groupBy('mapel.nama_mapel')
    ->orderBy('avg_score', 'asc')
    ->take(5)
    ->get();

echo "Hardest Subjects (Lowest Avg):\n";
foreach($hardest as $h) {
    echo "- " . $h->nama_mapel . ": " . round($h->avg_score, 2) . "\n";
}

echo "\n";

// Get top 5 subjects with highest average (Easiest)
$easiest = NilaiSiswa::join('mapel', 'nilai_siswa.id_mapel', '=', 'mapel.id')
    ->select('mapel.nama_mapel', DB::raw('AVG(nilai_siswa.nilai_akhir) as avg_score'))
    ->groupBy('mapel.nama_mapel')
    ->orderBy('avg_score', 'desc')
    ->take(5)
    ->get();

echo "Easiest Subjects (Highest Avg):\n";
foreach($easiest as $e) {
    echo "- " . $e->nama_mapel . ": " . round($e->avg_score, 2) . "\n";
}
